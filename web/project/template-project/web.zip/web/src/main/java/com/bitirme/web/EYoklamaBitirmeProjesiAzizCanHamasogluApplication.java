package com.bitirme.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EYoklamaBitirmeProjesiAzizCanHamasogluApplication {

	public static void main(String[] args) {
		SpringApplication.run(EYoklamaBitirmeProjesiAzizCanHamasogluApplication.class, args);
	}

}
